package ncs.test6;

public class EmptyException extends Exception{

	public EmptyException(String arg0) {
		super(arg0);
	}
}
