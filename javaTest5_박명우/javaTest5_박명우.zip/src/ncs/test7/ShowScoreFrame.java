package ncs.test7;

public class ShowScoreFrame {

	public static void main(String[] args) {
		new ScoreFrame();
	}
}
