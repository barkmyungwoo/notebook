package client.game;

public class MoleGameTestMain {

	public static void main(String[] args) {
		new MoleGame();
	}

}
