package client.game;

public class PoketmonGameTestMain {

	public static void main(String[] args) {
		new poketmonGame(null, null);

	}

}
