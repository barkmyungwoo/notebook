package client;

public class SaveScore {
private int score = 0;

public int get() {
	return score;
}

public void set(int score) {
	this.score = score;
}
}
